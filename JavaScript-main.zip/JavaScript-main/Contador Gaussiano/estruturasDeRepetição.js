function Contar(){
var valorInicial=document.getElementById("valorInicial").value;
valorInicial=Number(valorInicial);
var valorFinal=document.getElementById("valorFinal").value;
valorFinal=Number(valorFinal);

var contador = 1;
var acumulador =0;

while (contador<=valorFinal){

acumulador+=contador;
contador++;
}
console.log(acumulador);
alert(acumulador);
alert(contador);
}