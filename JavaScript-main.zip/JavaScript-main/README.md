// Repositório para atividades e projetos feitos durante o Curso Técnico em Dev de Sistemas.
// handle with care!
